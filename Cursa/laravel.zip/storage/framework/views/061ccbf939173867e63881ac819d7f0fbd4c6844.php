    <?php $__env->startSection('template_title'); ?>
    racePage
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <!--SCRIPTS-->
    <link href='https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css' rel='stylesheet'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css' rel='stylesheet'>
    <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
    <script type='text/javascript' src='https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js'></script>

    <div class="super_container">
        <header class="header" style="display: none;">
            <div class="header_main">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-12 order-lg-2 order-3 text-lg-left text-right">
                            <div class="header_search">
                                <div class="header_search_content">
                                    <div class="header_search_form_container">
                                        <form action="#" class="header_search_form clearfix">
                                            <div class="custom_dropdown">
                                                <div class="custom_dropdown_list"> <span class="custom_dropdown_placeholder clc">All Categories</span> <i class="fas fa-chevron-down"></i>
                                                    <ul class="custom_list clc">
                                                        <li><a class="clc" href="#">All Categories</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="single_product">
            <div class="container-fluid" style=" background-color: #fff; padding: 11px;">
                <div class="row">
                    <div class="col-lg-2 order-lg-1 order-2">
                        <ul class="image_list">
                            <li><img src="/mapsImages/<?php echo e($race->maps_image); ?>" ></li>

                        </ul>
                    </div>
                    <div class="col-lg-4 order-lg-2 order-1">
                        <div class="image_selected"><img src="/promotionalPosters/<?php echo e($race->promotional_poster); ?>" alt=""></div>
                    </div>
                        <div class="col-lg-6 order-3">
                            <div class="product_description">

                                <div class="product_name"> <?php echo e($race->name); ?></div>
                                <div> <span class="product_price"><?php echo e($race->race_price); ?>€</span> <strike class="product_discount"> <span style='color:black'><?php echo e($race->race_price+20); ?>€<span> </strike> </div>
                                <div> <span class="product_saved">You Saved:</span> <span style='color:black'>20€<span> </div>
                                <div> <span class="product_info">Start of bike race: <?php echo e($race->date); ?><span></div>
                                <hr class="singleline">
                                <div> <span class="product_info"><?php echo e($race->description); ?><span></div>
                                <div>
                                    <div class="row">

                                        <div class="col-md-7"> </div>
                                    </div>
                                    <div class="row" style="margin-top: 15px;">
                                        <div class="col-xs-6" > <span class="product_options">Ramp: <?php echo e($race->ramp); ?></span><br> </div>
                                        <div class="col-xs-6" > <span class="product_options"><?php echo e($race->km); ?>km</span><br></div>

                                    </div>
                                    <?php if($date < $race->date): ?>
                                        <br>
                                        <div> <span class="product_info">Sign up for our race<span></div>
                                        <a href="<?php echo e(route('runnerForm',$race->id )); ?>" class="btn btn-primary">Enroll in the race</a>
                                    <?php endif; ?>
                                    <br>
                                    <div class="product_name">Sponsors</div>

                                    <?php $__currentLoopData = $sponsorImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <img src="/logoImages/<?php echo e($sponsor['logo']); ?>" width="100px">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if(count($raceImage) > 0): ?>
                    <div class="container py-5">
                        <section class="pt-5 pb-5">
                            <div class="container">
                                <div class="row">
                                    <div class="col-6">
                                        <h3 class="mb-3">Gallery</h3>
                                    </div>
                                    <div class="col-6 text-right">
                                        <a class="btn btn-primary mb-3 mr-1" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                            <i class="fa fa-arrow-left"></i>
                                        </a>
                                        <a class="btn btn-primary mb-3 " href="#carouselExampleIndicators" role="button" data-slide="next">
                                            <i class="fa fa-arrow-right"></i>
                                        </a>
                                    </div>
                                    <div class="col-12">
                                        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                                            <div class="carousel-inner">
                                                <div class="carousel-item active">
                                                    <div class="row">
                                                        <?php for($i = 0; $i < 3; $i++): ?>
                                                            <?php if(isset($raceImage[$i])): ?>
                                                                <div class="col-md-4 mb-3">
                                                                    <div class="card">
                                                                        <img class="img-fluid p-2" alt="100%x280" src="/images/<?php echo e($raceImage[$i]->race_image); ?>">
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                                <?php for($i = 1; $i < intval(ceil((count($raceImage)-3)/3)+1); $i++): ?>
                                                <div class="carousel-item">
                                                    <div class="row">
                                                        <?php for($j = intval($i*3); $j < intval(($i*3)+3); $j++): ?>
                                                            <?php if(isset($raceImage[$j])): ?>
                                                                <div class="col-md-4 mb-3">
                                                                    <div class="card">
                                                                        <img class="img-fluid" alt="100%x280" src="/images/<?php echo e($raceImage[$j]->race_image); ?>">
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Race\Cursa\resources\views/race/racePage.blade.php ENDPATH**/ ?>