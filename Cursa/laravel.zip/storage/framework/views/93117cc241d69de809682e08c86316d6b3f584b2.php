
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="payment-box shadow">
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            
        <?php endif; ?>
        <div class="payment-box">
            <h1><?php echo e($amount.'€'); ?></h1>
            <form action="<?php echo e(route('requestpayment')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="amount" placeholder="Enter The Price" value="<?php echo e($amount); ?>" class="form-control">
                <input type="submit"  value="PayPal" class="btn-container-module-paypal">

            </form>
        </div>


    </div>

</div>
<script src="https://www.paypal.com/sdk/js?client-id=env('PAYPAL_SANDBOX_CLIENT_ID')"></script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Race\Cursa\resources\views/paypal/index.blade.php ENDPATH**/ ?>