

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/totalPriceRace.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php if (! $__env->hasRenderedOnce('631e2da8-2563-49ba-8487-caf0bec8b122')): $__env->markAsRenderedOnce('631e2da8-2563-49ba-8487-caf0bec8b122'); ?>
    <?php $__env->startPush('scripts'); ?>
      <script src="<?php echo e(asset('js/totalPriceRace.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
<?php if($lleno == true): ?>
  <h1>Carrera Llena</h1>
<?php else: ?>
<?php if(Session::has('error')): ?>
  <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
    <a href="<?php echo e(route('generatePDF', $response['id'].','.$response['status'].','.$response['payment_source']['paypal']['name']['given_name'].','.$response['payment_source']['paypal']['name']['surname'].','.$response['purchase_units'][0]['payments']['captures'][0]['seller_receivable_breakdown']['gross_amount']['value'])); ?>" class="btn btn-primary"> Generate invoice (PDF)</a>

<?php endif; ?>
<p class="text-center">
  <a class="btn btn-primary" data-bs-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">Register with ID</a>
  <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample2" aria-expanded="false" aria-controls="multiCollapseExample2">Register from scratch</button>
</p>
    <div class="row">
      <div class="col-6">
        <div class="collapse multi-collapse" id="multiCollapseExample1">
          <div class="card card-body">
            <?php echo e(method_field('PATCH')); ?>

            <?php echo csrf_field(); ?>
            <?php echo $__env->make('race.runnerFormDni', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
      </div>
      <div class="col-6">
        <div class="collapse multi-collapse" id="multiCollapseExample2">
          <div class="card card-body">
            <?php echo e(method_field('PATCH')); ?>

            <?php echo csrf_field(); ?>
            <?php echo $__env->make('race.runnerFormRegister', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
      </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Race\Cursa\resources\views/race/runnerForm.blade.php ENDPATH**/ ?>