<div class="box box-info padding-1">
    <div class="box-body">
        <div class="form-group">
            <?php echo e(Form::label('cif')); ?>

            <?php echo e(Form::text('cif', $insurer->cif, ['class' => 'form-control' . ($errors->has('cif') ? ' is-invalid' : ''), 'placeholder' => 'Cif'])); ?>

            <?php echo $errors->first('cif', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('name')); ?>

            <?php echo e(Form::text('name', $insurer->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('address')); ?>

            <?php echo e(Form::text('address', $insurer->address, ['class' => 'form-control' . ($errors->has('address') ? ' is-invalid' : ''), 'placeholder' => 'Address'])); ?>

            <?php echo $errors->first('address', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
    </div>
    <div class="box-body">
        <div>Register in Races...</div>
        <div class="form-group row row-cols-5">
            <?php $__currentLoopData = $races; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $race): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check form-switch col">
                    <input class="form-check-input" type="checkbox" id="check<?php echo e($race->id); ?>" name="race[<?php echo e($race->id); ?>][]" onchange="(document.getElementById('<?php echo e($race->id); ?>').disabled == true) ? document.getElementById('<?php echo e($race->id); ?>').disabled = false: document.getElementById('<?php echo e($race->id); ?>').disabled = true;">
                    <label class="form-check-label" for="check<?php echo e($race->id); ?>">Race - <?php echo e($race->id); ?></label>
                    <br>
                    <label for="<?php echo e($race->id); ?>" class="form-label">Price</label>
                    <input type="number" class="form-control" id="<?php echo e($race->id); ?>" name="race[<?php echo e($race->id); ?>][]" disabled required>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary mt-2">Submit</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Race\Cursa\resources\views/insurer/form.blade.php ENDPATH**/ ?>