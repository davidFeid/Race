<footer class=" footer absolute-bottom py-4 bg-dark text-white-50">
  <div class="container text-center"> 
    <small>Copyright &copy; Biketour Experience</small>
    <a href="https://github.com/davidFeid/Race" data-toggle="tooltip" data-placement="top" title="" data-original-title="Github" target="blank"><img class="img-footer" src="\images\icons8-github.svg" ></a>
  </div>
</footer><?php /**PATH C:\xampp\htdocs\Race\Cursa\resources\views/layouts/footerGeneral.blade.php ENDPATH**/ ?>