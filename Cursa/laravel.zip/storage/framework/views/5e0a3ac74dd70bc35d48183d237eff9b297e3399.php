
    <?php $__env->startSection('template_title'); ?>
    Home
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="container py-5">
            <h1>All our races</h1>
            <!-- For Demo Purpose -->

            <!-- DEMO 5 -->

            <div class="row row-cols-1 row-cols-md-2 g-4">
            <?php $__currentLoopData = $races; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $race => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($diaActual<$value->date): ?>
                <div class="col-md-4">
                            <h4 class="text-center"><strong><?php echo e($value->name); ?></strong></h4>
                            <hr>
                            <a class="dropdown-item" href="<?php echo e(route('racePage',$value->id)); ?>">
                                <div class="profile-card-6"><img src="/promotionalPosters/<?php echo e($value->promotional_poster); ?>"  width="100%" class="img img-responsive">
                                    <div class="profile-name"> <?php echo e($value->date); ?></div>
                                    <div class="profile-position"><?php echo e(substr($value->description, 0, 18)."..."); ?></div>
                                    <div class="profile-overview">
                                        <div class="profile-overview">
                                            <div class="row text-center">
                                                <div class="col-xs-4">
                                                    <h3>Price</h3>
                                                    <p><?php echo e($value->race_price); ?>€</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                <?php else: ?>
                    <div class="col-md-4">
                        <h4 class="text-center finishedRace"><strong><?php echo e($value->name); ?> / Finished race </strong></h4>
                        <hr>
                        <a class="dropdown-item" href="<?php echo e(route('racePage',$value->id)); ?>">
                            <div class="profile-card-6"><img src="/promotionalPosters/<?php echo e($value->promotional_poster); ?>"  width="100%" class="img img-responsive">
                                <div class="profile-name"> <?php echo e($value->date); ?></div>
                                <div class="profile-position"><?php echo e(substr($value->description, 0, 18)."..."); ?></div>
                                <div class="profile-overview">
                                    <div class="profile-overview">
                                        <div class="row text-center">
                                            <div class="col-xs-4">
                                                <h3>Price</h3>
                                                <p><?php echo e($value->race_price); ?>€</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Race\Cursa\resources\views/race/allRaces.blade.php ENDPATH**/ ?>