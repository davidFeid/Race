

<?php $__env->startSection('template_title'); ?>
    <?php echo e($race->name ?? 'Show Race'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Race</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('races.index')); ?>"> Back</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <h2>Ranking Runners</h2>
                        <table class='table table-bordered'>
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Age</th>
                                <th>QR</th>
                                <th>Dorsal</th>
                                <th>Time</th>
                                <th>Points</th>
                                <th>Insurer</th>
                            </tr>

                            <?php $__currentLoopData = $runners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $runner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($runner->runner->dni); ?></td>
                                    <td><?php echo e($runner->runner->name); ?></td>
                                    <td><?php echo e($runner->runner->address); ?></td>
                                    <td><?php echo e($runner->runner->birth_date); ?></td>
                                    <td><img src="/qrcodes/<?php echo e($runner->qr); ?>" /></td>
                                    <td><?php echo e($runner->dorsal); ?></td>
                                    <td><?php echo e($runner->time); ?></td>
                                    <td><?php echo e($runner->points); ?></td>
                                    <?php if(isset($runner->insurer->name)): ?>
                                        <td><?php echo e($runner->insurer->name); ?></td>
                                    <?php else: ?>
                                        <td>Federado</td>
                                    <?php endif; ?>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>
                </div>

                <?php echo $__env->make('race.upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Race\Cursa\resources\views/race/show.blade.php ENDPATH**/ ?>