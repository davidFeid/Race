<div class="box box-info padding-1">
    <div class="box-body">

        <div class="form-group">
            <?php echo e(Form::label('cif')); ?>

            <?php echo e(Form::text('cif', $sponsor->cif, ['class' => 'form-control' . ($errors->has('cif') ? ' is-invalid' : ''), 'placeholder' => 'Cif'])); ?>

            <?php echo $errors->first('cif', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('name')); ?>

            <?php echo e(Form::text('name', $sponsor->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('address')); ?>

            <?php echo e(Form::text('address', $sponsor->address, ['class' => 'form-control' . ($errors->has('address') ? ' is-invalid' : ''), 'placeholder' => 'Address'])); ?>

            <?php echo $errors->first('address', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('email')); ?>

            <?php echo e(Form::email('email', $sponsor->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

            <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Appear on Home:')); ?><br>
            <?php echo e(Form::label('yes')); ?>

            <?php echo e(Form::radio('home', '1', ['class' => 'form-control' . ($errors->has('home') ? ' is-invalid' : ''), 'placeholder' => 'Home'])); ?>

            <?php echo e(Form::label('no')); ?>

            <?php echo e(Form::radio('home', '0', ['class' => 'form-control' . ($errors->has('home') ? ' is-invalid' : ''), 'placeholder' => 'Home'])); ?>

            <?php echo $errors->first('home', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('total')); ?>

            <?php echo e(Form::number('total', $sponsor->total, ['class' => 'form-control' . ($errors->has('total') ? ' is-invalid' : ''), 'placeholder' => 'Total'])); ?>

            <?php echo $errors->first('total', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('logo')); ?>

            <?php echo e(Form::file('logo', $sponsor->logo, ['class' => 'form-control' . ($errors->has('logo') ? ' is-invalid' : ''), 'placeholder' => 'Logo'])); ?>

            <?php echo $errors->first('logo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="box-body">
            <div>Register in Races...</div>
            <div class="form-group row row-cols-5">
                <?php $__currentLoopData = $races; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $race): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check form-switch col">
                        <input class="form-check-input" type="checkbox" id="check<?php echo e($race->id); ?>" name="race[<?php echo e($race->id); ?>][]" onchange="(document.getElementById('<?php echo e($race->id); ?>').disabled == true) ? document.getElementById('<?php echo e($race->id); ?>').disabled = false: document.getElementById('<?php echo e($race->id); ?>').disabled = true;">
                        <label class="form-check-label" for="check<?php echo e($race->id); ?>">Race - <?php echo e($race->id); ?></label>
                        <br>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Race\Cursa\resources\views/sponsor/form.blade.php ENDPATH**/ ?>