
    <?php $__env->startSection('template_title'); ?>
    Home
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="container py-5">
            <h1>Busqueda "<?php echo e($busqueda); ?>"</h1>
            <!-- For Demo Purpose -->

            <!-- DEMO 5 -->
        
            <?php $__currentLoopData = $races; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $race => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="py-5">
                        <h3 class="font-weight-bold mb-0"><?php echo e($value->name); ?></h3>
                        <div class="row">
                        <!-- DEMO 5 Item-->
                        <div class="col-lg-6 mb-3 mb-lg-0">
                            <div class="hover hover-5 text-white rounded">

                                <a class="dropdown-item" href="<?php echo e(route('racePage',$value->id)); ?>">
                                    <img src="/promotionalPosters/<?php echo e($value->promotional_poster); ?>" width="100px" alt="">
                                    <div class="hover-overlay"></div>
                                    <div class="hover-5-content">
                                        <h3 class="hover-5-title text-uppercase font-weight-light mb-0"><?php echo e(substr($value->description, 0, 18)."..."); ?><span> more info</span></h3>
                                    </div>
                                </a>
                            </div>
                        </div>
                        </div>
                    </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Race\Cursa\resources\views/race/search.blade.php ENDPATH**/ ?>